#!/usr/bin/env bash

#SBATCH --time=0-1:00:00
#SBATCH --nodes=1
#SBATCH --mem=120G
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=4
#SBATCH -o log_Post_Maker-%j.out
#SBATCH -e log_Post_Maker-%j.err
#SBATCH --account=rpp-rieseber

#BLASTP="/home/jmlazaro/maker/bin/../exe/blast/bin/blastp"
BLASTP="/home/jmlazaro/scratch/ncbi-blast-2.12.0+/bin/blastp"

ml r/4.1.0
