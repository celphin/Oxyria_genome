#!/usr/bin/env bash

#SBATCH --time=0-12:00:00
#SBATCH --nodes=6
#SBATCH --mem=120G
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=4
#SBATCH -o log_Maker-%j.out
#SBATCH -e log_Maker-%j.err
#SBATCH --account=rpp-rieseber

ml postgresql/13.2
ml openmpi/4.0.3

mpiexec --use-hwthread-cpus maker
#srun maker

ml unload postgresql/13.2
ml openmpi/4.0.3
